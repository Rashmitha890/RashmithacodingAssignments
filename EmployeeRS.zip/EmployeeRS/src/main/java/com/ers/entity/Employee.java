package com.ers.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="Employee1")
public class Employee {
	
		@Id
	  //@GeneratedValue(strategy=GenerationType.IDENTITY)
		private String Id;//composite
		private String password;
		private String employeeName;
		private String designation;
		private String department;
		private String email;
		private String type;
		public boolean valid;
		public String getId() {
			return Id;
		}
		public void setId(String Id) {
			this.Id = Id;
		}
		public String getpassword() {
			return password;
		}
		public void setpassword(String password) {
			this.password = password;
		}
		public String getEmployeeName() {
			return employeeName;
		}
		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public boolean isValid() {
			return valid;
		}
		public void setValid(boolean newValid)
		{
			valid=newValid;
		}
	}
