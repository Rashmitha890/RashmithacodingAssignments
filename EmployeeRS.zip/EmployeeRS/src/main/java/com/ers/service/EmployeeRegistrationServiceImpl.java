package com.ers.service;

import java.util.List;

import com.ers.dao.EmployeeRegistrationDaoImpl;
import com.ers.entity.Employee;
import com.ers.model.Employee;

public class EmployeeRegistrationServiceImpl implements EmployeeService{
	EmployeeRegistrationDaoImpl employeeDao=new EmployeeRegistrationDaoImpl();
	public void addEmployee(Employee e) {
		 employeeDao.addEmployee(e);
		 
	 }
		 
	 }