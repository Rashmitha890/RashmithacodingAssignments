package com.ers.service;

import java.util.List;

import com.ers.dao.EmployeeDao;
import com.ers.dao.EmployeeDaoImplementation;
import com.ers.entity.ReimbursementRequest;
import com.ers.entity.Employee;

public class EmployeeServiceImplementation implements EmployeeService {
	private EmployeeDao ed=new EmployeeDaoImplementation();

	public Employee login(String userId, String password) {
		Employee e=ed.login(userId, password);
		return e;
	}

	public void logout() {
		// TODO Auto-generated method stub
	}

	public List<ReimbursementRequest> getPendingReimbursementRequest(int userId) {
		ed.getPendingReimbursementRequest(userId);
		return null;
	}

	public List<ReimbursementRequest> getResolvedReimbursementRequest(int userId) {
		ed.getResolvedReimbursementRequest(userId);
		return null;
	}

	public Employee getProfile(int userId) {
		ed.getProfile(userId);
		return null;
	}

	public boolean updateProfile(Employee e) {
		ed.updateProfile(e);
		return false;
	}

}
