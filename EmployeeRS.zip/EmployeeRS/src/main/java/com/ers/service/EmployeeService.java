package com.ers.service;

import java.util.List;

import com.ers.entity.ReimbursementRequest;
import com.ers.entity.Employee;

public interface EmployeeService {
	 Employee login(String userId,String password);
	 void logout();
	 List<ReimbursementRequest> getPendingReimbursementRequest(int userId);
	 List<ReimbursementRequest> getResolvedReimbursementRequest(int userId);
	 Employee getProfile(int userId);
	 boolean updateProfile(Employee e);
}