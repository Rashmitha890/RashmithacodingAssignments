package com.ers.db;

import com.ers.entity.Employee;
import com.ers.model.Employee;

public class EmployeeMapper {
	
	public static Employee mapEmployee(Employee e) {
		Employee entity=new Employee();
		entity.setId(e.getId());
		entity.setEmployeeName(e.getEmployeeName());
		entity.setDesignation(e.getDesignation());
		entity.setDepartment(e.getDepartment());
		entity.setEmail(e.getEmail());
		entity.setpassword(e.getpassword());
		entity.setType(e.getType());
		return entity;
		
	}

}