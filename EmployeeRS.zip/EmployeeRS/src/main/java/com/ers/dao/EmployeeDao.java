package com.ers.dao;

import java.util.List;

import com.ers.entity.ReimbursementRequest;
import com.ers.entity.Employee;

public interface EmployeeDao {
	 Employee login(String userId,String password);
	 void logout();
	 List<ReimbursementRequest> getPendingReimbursementRequest(int userId);
	 List<ReimbursementRequest> getResolvedReimbursementRequest(int userId);
	 Employee getProfile(int userId);
	 boolean updateProfile(Employee e);
}
