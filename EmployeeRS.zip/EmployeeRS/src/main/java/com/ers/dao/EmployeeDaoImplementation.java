package com.ers.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

import com.ers.db.HibernateUtil;
import com.ers.entity.ReimbursementRequest;
import com.ers.entity.Employee;

public class EmployeeDaoImplementation implements EmployeeDao {
	private SessionFactory sf=HibernateUtil.getSessionFactory();
	private Session s;

	public Employee login(String userId, String password) {
		Employee emp=null;
		try {
			s=sf.openSession();
			Query q=s.createQuery("FROM Employee WHERE Id=:id AND password=:pass");
			
			q.setParameter("id",userId);
			q.setParameter("pass",password);
			List<Employee> el=q.list();
			if(!el.isEmpty())
				emp=(Employee)el.get(0);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			if(s!=null)
				s.close();
		}
		return emp;
	}

	public void logout() {
		// TODO Auto-generated method stub

	}

	public List<ReimbursementRequest> getPendingReimbursementRequest(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ReimbursementRequest> getResolvedReimbursementRequest(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee getProfile(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean updateProfile(Employee e) {
		// TODO Auto-generated method stub
		return false;
	}

}
