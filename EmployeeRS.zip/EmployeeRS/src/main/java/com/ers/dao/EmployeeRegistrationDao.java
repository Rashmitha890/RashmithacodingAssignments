package com.ers.dao;

import java.util.List;

import com.ers.entity.Employee;
import com.ers.model.Employee;

public interface EmployeeRegistrationDao {
	 public void addEmployee(Employee e);
}