package com.ers.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.query.Query;

import com.ers.db.EmployeeMapper;
import com.ers.db.HibernateUtil;
import com.ers.entity.Employee;
import com.ers.model.Employee;

public class EmployeeRegistrationDaoImpl {
	
	
	 public void addEmployee(Employee e) {
		 try {
				
				Session session=HibernateUtil.getSessionFactory().openSession();
			
				session.beginTransaction();  
				session.save(e);
				System.out.println("employee inserted...");
				session.getTransaction().commit();
				session.close();
				
			} catch (Exception e1) {
				
				e1.printStackTrace();
			}
	 }
	 public static void main(String [] args) {
		 EmployeeRegistrationDaoImpl erd=new EmployeeRegistrationDaoImpl();
		 Employee e=new Employee();
		 e.setId(88);
		 e.setDepartment("CSE");
		 e.setDesignation("Arichs");
		 e.setEmail("q@gmail.com");
		 e.setpassword("111");
		 e.setEmployeeName("na");
		 e.setType("emp");
		 erd.addEmployee(e);
	 }
}