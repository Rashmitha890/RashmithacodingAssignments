package com.ers.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ers.entity.Employee;
import com.ers.service.EmployeeService;
import com.ers.service.EmployeeServiceImplementation;

@WebServlet("/employee-login")
public class EmployeeLoginServlet extends HttpServlet {
	private Integer Id;
	private EmployeeService sld=new EmployeeServiceImplementation();
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
			String userid=request.getParameter("Id");
			String password=request.getParameter("password");
			Employee e=sld.login(userid, password);
			
			RequestDispatcher rd=null;
			
			if(e==null) {
				rd=request.getRequestDispatcher("/EmployeeRS/login.jsp");
			}else {
				System.out.println(e.getType());
				if(e.getType().equalsIgnoreCase("manager"))
					rd=request.getRequestDispatcher("/EmployeeRS/manager-dashboard.jsp");
				else
					rd=request.getRequestDispatcher("/employee-dashboard.jsp");
				rd.forward(request, response);
			}
				
	}	
		
}