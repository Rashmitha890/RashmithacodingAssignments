package com.ers.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ers.bo.IDGenerator;
import com.ers.entity.Employee;
import com.ers.service.EmployeeRegistrationServiceImpl;

public class EmployeeServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String Id=request.getParameter("Id");
		String password=request.getParameter("password");
		String name=request.getParameter("EmployeeName");
		String des=request.getParameter("des");
		String dep=request.getParameter("dep");
		String email=request.getParameter("email");
		String type=request.getParameter("type");
	//	String newid=IDGenerator.generateID();
		//model is mapped
		Employee e=new Employee();
		e.setId(Integer.parseInt(Id));
		e.setEmployeeName(name);
		e.setDepartment(dep);
		e.setDesignation(des);
		e.setType(type);
		e.setEmail(email);
		e.setpassword(password);
		//System.out.println(name+" "+dep+" ");
	
		
		//service need to be invoked 
		EmployeeRegistrationServiceImpl employeeService =new EmployeeRegistrationServiceImpl();
		employeeService.addEmployee(e);
		out.print(" Registration success");
		RequestDispatcher rd=request.getRequestDispatcher("login.html");
		rd.include(request, response);
	}

}